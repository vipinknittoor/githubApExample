package com.meshi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication 

// autoscan search for controller and be ready to accpet any HTTP req 
// autoconfiguration app.properties 
public class MeshiApplication {

	public static void main(String[] args) {
		SpringApplication.run(MeshiApplication.class, args);
	}

}
