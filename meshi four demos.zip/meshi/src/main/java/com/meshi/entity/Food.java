package com.meshi.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Entity
@Data 
@AllArgsConstructor
@NoArgsConstructor
public class Food {

	@Id
	private String 	fid ;
	private String fname ;
	private String ftype ;
	private int fcost;
}
