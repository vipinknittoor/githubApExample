package com.meshi.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.meshi.entity.User;
import com.meshi.service.UserService;

@RestController
public class UserController {
	@Autowired
	UserService userService;
	
	@GetMapping("/meshi")
	public String fun()
	{
		return "meshi";
	}

	
	@PostMapping("/meshi/adduser")
	public User adduser(@RequestBody User user)
	{
		System.out.println("inside add user meshi");
		return userService.adduser(user);
		 
		
		
	}
	
	@GetMapping("/meshi/{uid}")
	public Optional<User> finduser(@PathVariable String uid)
	{
		System.out.println("inside add user meshi to find one user ");
		return userService.finduser(uid);
		 
		
		
	}
}
