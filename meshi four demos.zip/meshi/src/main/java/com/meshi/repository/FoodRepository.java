package com.meshi.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.meshi.entity.Food; 

public interface FoodRepository extends JpaRepository<Food, String>{

}
