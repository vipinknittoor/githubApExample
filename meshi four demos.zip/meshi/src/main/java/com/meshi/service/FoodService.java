package com.meshi.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.meshi.entity.Food; 
import com.meshi.repository.FoodRepository; 

@Service 
public class FoodService {
	@Autowired
	FoodRepository foodRepository;
	
	public Food addFood( Food food)
	{
		System.out.println("inside add food service  meshi");
		return foodRepository.save(food);
		
		
	}

	public  Optional<Food> findfood(String fid) {
		// TODO Auto-generated method stub
		return  foodRepository.findById(fid);
	}

}
