package com.meshi;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import com.meshi.entity.User;

@FeignClient(value = "user" , url="http://localhost:8020"  )
public interface MeshiFeignClientUser {
	
	@GetMapping("/meshi")
	public String fun();
	@GetMapping("/meshi/user")
	public List<User> fun1();

}
