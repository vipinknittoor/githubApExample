package com.meshi;

import java.util.Optional;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.meshi.entity.Food;

@FeignClient(name = "FoodApp" ,url = "http://localhost:8010")
public interface MeshiFeignClientFood {

	
	@GetMapping("/food/{fid}")
	public Optional<Food> findfood(@PathVariable String fid);
	 
}
