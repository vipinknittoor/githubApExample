package com.meshi.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.meshi.entity.Food;
import com.meshi.entity.User;
import com.meshi.service.FoodService;
import com.meshi.service.UserService;

@RestController
@RequestMapping("/meshi")
public class UserController {
	@Autowired
	UserService userService;
	
	@Autowired
	FoodService foodService; 
	
	@GetMapping("/hi")
	public String fun() {
		return "meshi";
	}

	@GetMapping("/user")
	public List<User> fun1() {
		return userService.getUser();
	}

	@GetMapping("/food")
	public  Optional<Food> fun2() {
		return foodService.getFood();
	}
}
