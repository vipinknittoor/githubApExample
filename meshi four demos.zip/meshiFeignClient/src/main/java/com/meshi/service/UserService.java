package com.meshi.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.meshi.MeshiFeignClientUser;
import com.meshi.entity.User; 

@Service 
public class UserService {
  @Autowired
  MeshiFeignClientUser clientUser;
 
	public List<User> getUser() {
		// TODO Auto-generated method stub
		return  clientUser.fun1();
	}

}
