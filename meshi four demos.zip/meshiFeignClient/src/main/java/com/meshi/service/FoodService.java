package com.meshi.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.meshi.MeshiFeignClientFood;
import com.meshi.entity.Food;
import com.meshi.entity.User;

@Service
public class FoodService {
	@Autowired
	MeshiFeignClientFood clientFood;

	public  Optional<Food> getFood() {
		// TODO Auto-generated method stub
		return clientFood.findfood("99");
	}
	
	
	

}
