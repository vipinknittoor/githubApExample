package com.meshi.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.meshi.entity.Food; 
import com.meshi.service.FoodService; 

@RestController
public class FoodController {
	@Autowired
	FoodService foodService;
	
	@GetMapping("/food")
	public String fun()
	{
		return "food";
	}

	
	@PostMapping("/food/addfood")
	public Food addfood(@RequestBody Food food)
	{
		System.out.println("inside add food meshi");
		return foodService.addFood(food);
		 
		
		
	}
	
	@GetMapping("/food/{fid}")
	public Optional<Food> findfood(@PathVariable String fid)
	{
		System.out.println("inside add user meshi to find one user ");
		return foodService.findfood(fid);
		 
		
		
	}
}
