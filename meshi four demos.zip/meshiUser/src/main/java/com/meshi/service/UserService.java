package com.meshi.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.meshi.entity.User;
import com.meshi.repository.UserRepository;

@Service 
public class UserService {
	@Autowired
	UserRepository userRepository;
	
	public User adduser(  User user)
	{
		System.out.println("inside add user service  meshi");
		return userRepository.save(user);
		
		
	}

	public  Optional<User> finduser(String uid) {
		// TODO Auto-generated method stub
		return userRepository.findById(uid);
	}

	public List<User> getUser() {
		// TODO Auto-generated method stub
		return userRepository.findAll();
	}

}
