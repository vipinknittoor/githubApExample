package com.meshi.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.meshi.DTO.UserDTO;
import com.meshi.entity.Food;
import com.meshi.entity.User;
import com.meshi.service.UserService;

@RestController
public class UserController {
	@Autowired
	UserService userService;

	@Autowired
	RestTemplate restTemplate;

	@GetMapping("/meshi")
	public String fun() {
		return "meshi";
	}

	@GetMapping("/meshi/user")
	public List<User> fun1() {
		return userService.getUser();
	}

	@PostMapping("/meshi/adduser")
	public User adduser(@RequestBody User user) {
		System.out.println("inside add user meshi");
		return userService.adduser(user);

	}

	@GetMapping("/meshi/{uid}")
	public UserDTO finduser(@PathVariable String uid) {
		System.out.println("inside add user meshi to find one user ");

		User user = userService.finduser(uid).get();
		String fid = user.getFid();
		String url = "http://localhost:8010/food/";
		url = url + fid;
		Food food = restTemplate.getForObject(url, Food.class);

		UserDTO userDTO = new UserDTO();
		userDTO.setFood(food);
		userDTO.setUser(user);
		return userDTO;

	}
}
