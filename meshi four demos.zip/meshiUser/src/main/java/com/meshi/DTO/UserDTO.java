package com.meshi.DTO;

import com.meshi.entity.Food;
import com.meshi.entity.User;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserDTO {

	private Food food;
	private User user;

}
